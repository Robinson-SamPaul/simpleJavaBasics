import java.util.ArrayList;
import java.util.List;

public class AdjacencySetGraph implements Graph {

    private List<Vertex> vertexList = new ArrayList<>();

    private int numVertices = 0;

    private GraphType graphType = GraphType.DIRECTED;

    public AdjacencySetGraph(int numVertices, GraphType graphType) {
        
    	this.numVertices = numVertices;
        
        for (int i = 0; i < numVertices; i++) {
            vertexList.add(new Vertex(i));
        }

        this.graphType = graphType;
    }

    @Override
    public void addEdge(int v1, int v2) {
    	
    	if (v1 >= numVertices || v1 < 0 || v2 >= numVertices || v2 < 0) {
            throw new IllegalArgumentException("Vertex number is not valid: " + v1 + ", " + v2);
        }

        vertexList.get(v1).addEdge(v2);

        if (graphType == GraphType.UNDIRECTED) {
            vertexList.get(v2).addEdge(v1);
        }
    }


    @Override
    public List<Integer> getAdjacentVertices(int v) {
        
    	if (v >= numVertices || v < 0) {
            throw new IllegalArgumentException("Vertex number is not valid: " + v);
        }

        return vertexList.get(v).getAdjacentVertices();
    }

	@Override
	public int getIndegree(int v) {
		
		int indegree = 0;
		
		for (Vertex vertex : vertexList) {
			
			if (vertex.getAdjacentVertices().contains(v)) {
				
				indegree++;
			}
		}
		
		return indegree;
	}

	@Override
	public int getNumVertices() {
		return numVertices;
	}


	@Override
	public void displayGraph() {
        System.out.println("Adjacency Set\n");
        
		for (Vertex vertex : vertexList) {
			
			List<Integer> adjacentVertices = vertex.getAdjacentVertices();

            System.out.println("Edges from " + vertex.getVertexNumber() + 
            		" to : " + adjacentVertices);
		}

	}

}